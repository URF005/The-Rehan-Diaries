const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const fetchuser = require("../middleware/fetchuser");
const JWT_SECRET = "Shahzaib is a good boy";
const { body, validationResult } = require("express-validator");
const router = express.Router();
//Route 1: Create a user using Post "api/auth/createuser" No login rqeuired
router.post(
  "/createuser",
  [
    body("name", "Invalid Name").isLength({ min: 3 }),
    body("email", "Invalid Email").isEmail(),
    body("password", "Invalid Password must be 5 characters").isLength({ min: 5 }),
  ],

  async (req, res) => {
    let sucess=false;
    //If there are errors return errors and bad request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    //Check Whether the email exist already
    try {
      let user = await User.findOne({ email: req.body.email });
      console.log(user);
      if (user) {
        return res
          .status(400)
          .json({sucess, error: "Sorry this email already exist" });
      }
      const salt = await bcrypt.genSalt(10);
      const secpas = await bcrypt.hash(req.body.password, salt);

      user = await User.create({
        name: req.body.name,
        password: secpas,
        email: req.body.email,
      });
      const data = {
        user: {
          id: user.id,
        },
      };
      const authtoken = jwt.sign(data, JWT_SECRET);
      sucess=true;
      res.json({ sucess,authtoken });
    } catch (err) {
      console.log(err.message);
      res.status(500).send("Some error occurs");
    }
  }
);
//Route 2: auhtenticate a user using Post "api/auth/login" No login rqeuired
router.post(
  "/login",
  [
    body("email", "Invalid Email").isEmail(),
    body("password", "password cannot be blanked").exists(),
  ],

  async (req, res) => {
    let sucess=false;
    //If there are errors return errors and bad request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      const { email, password } = req.body;
      let user = await User.findOne({ email });
      if (!user) {
        sucess=false;
        return res
          .status(400)
          .json({sucess, error: "Please enter correct credential" });
      }
      const comppas = await bcrypt.compare(password, user.password);
      if (!comppas) {
        sucess=false;
        return res
          .status(400)
          .json({sucess, error: "Please enter correct credential" });
      }
      const data = {
        user: {
          id: user.id,
        },
      };
      const authtoken = jwt.sign(data, JWT_SECRET);
      sucess=true;
      res.json({sucess, authtoken });
    } catch (err) {
      console.log(err.message);
      res.status(400).send("Internal server error");
    }
  }
);
//Route:3 Get looged in user details  using Post "api/auth/getuser" login rqeuired
router.post("/getuser", fetchuser, async (req, res) => {
  //If there are errors return errors and bad request
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    userId = req.user.id;
    const user = await User.findById(userId).select("-password");
    res.send(user);
  } catch (err) {
    console.log(err.message);
    res.status(400).send("Internal server error");
  }
});

module.exports = router;
