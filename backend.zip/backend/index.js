const mongoose = require("mongoose");
const express = require("express");
var cors = require("cors");
const uri = "mongodb://127.0.0.1:27017/Mynotebook";

async function connectToMongo() {
  try {
    await mongoose.connect(uri);
    console.log("Connected to MongoDB!");
  } catch (err) {
    console.log("Failed to connect to MongoDB", err);
  }
}
connectToMongo();
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());
//Available routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/notes", require("./routes/notes"));

app.listen(port, () => {
  console.log(`iNotebook backend listening on port ${port}`);
});
